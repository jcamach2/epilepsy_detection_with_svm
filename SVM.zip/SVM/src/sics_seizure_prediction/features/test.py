from __future__ import absolute_import

import os.path
import re
import json
import glob
from collections import defaultdict


#A file which holds the names of the test segments
TESTSEGMENT_NAMES_FILE = '../../data/test_segment_names.json'


# def load_testsegment_names(name_file=TESTSEGMENT_NAMES_FILE):
#     print('Entered function')
#     """Loads the test segment names as a set of names.
#     :param name_file: The file with names to load.
#     :return: A set of test segment names. """
#     try:
#         with open(name_file, 'r') as fp:
#             names = json.load(fp)
#             return set(names)
#     except FileNotFoundError:
#         return generate_testsegment_names(name_file)


# def subprocess_call():
#     import subprocess
#     filenames = subprocess.check_output(['find', '../../data/', '-name', '*test*.mat']).split()
#     print filenames


# def generate_testsegment_names(name_file=TESTSEGMENT_NAMES_FILE):
#     """
#     Generates a json file containing all the canonical test file names. The file is saved to the path denoted by
#     the module constant TESTSEGMENT_NAMES_FILE'

#     :param name_file: A path to a file containing segment names.
#     :return: A set of all canonical test segment names.
#     """
#     print("Start generate test segment names ---------- ")
#     import subprocess
#     subprocess.call('find ../../data/ -name *test*.mat > output.txt', shell = True)
#     filenames = set(open('output.txt'))
#     decoded = [os.path.basename(name.decode()) for name in filenames]
#     matched_names = [re.match(r'([DP][a-z]*_[1-5]_[a-z]*_segment_[0-9]{4}).*', name) for name in decoded]
#     only_matches = [match.group(1) for match in matched_names if match]
#     only_matches.sort()
#     formatted_names = ["{}.mat".format(name) for name in only_matches]
#     with open(name_file, 'w') as fp:
#         json.dump(formatted_names, fp, indent=4, separators=(',', ': '))
#     print("Completed generate test segment names -----------")

#     return set(formatted_names)


def load_testsegment_names(name_file=TESTSEGMENT_NAMES_FILE):
    """Loads the test segment names as a set of names.
    :param name_file: The file with names to load.
    :return: A set of test segment names. """
    # try:
    #     with open(name_file, 'r') as fp:
    #         names = json.load(fp)
    #         return set(names)
    # except:
    #     print("Error, no file for testsegment_names found")
    #     return generate_testsegment_names(name_file)

#------------
load_testsegment_names()
